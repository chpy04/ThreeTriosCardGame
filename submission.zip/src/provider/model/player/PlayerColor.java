package provider.model.player;

/**
 * Represents a player's color.
 */
public enum PlayerColor {
  RED, BLUE
}