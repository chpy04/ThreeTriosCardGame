package provider.model.grid.cell;

/**
 * Enum representing the card cell status.
 */
public enum CellCardStatus {
  HOLE, EMPTY, FULL
}
